

<?php $__env->startSection('content'); ?>
<!-- Profile picture-->
<div id="zoom" style="background-color: <?php echo e($user->background_color); ?>">
    <img src="<?php echo e(asset('img/' . $user->image)); ?>" alt="profile picture" class="profile-picture">
</div>

<!-- Profile name-->
<div class="profile-name"><b><?php echo e($user->username); ?></b></div>

<?php $__currentLoopData = $user->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="link">
        <a 
        href="<?php echo e($link->link); ?>"
        data-link-id="<?php echo e($link->id); ?>"
        class="user-link links"
        target="_blank"
        rel="nofollow"
        style="border: 1px solid <?php echo e($user->text_color); ?>; color: <?php echo e($user->text_color); ?>"
        ><?php echo e($link->name); ?></a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="bottom-text">
    <a href="<?php echo e(route('home')); ?>">LinkMe</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MATERI KULIAH\Semester 5\PPAW\linkme\resources\views/users/show.blade.php ENDPATH**/ ?>