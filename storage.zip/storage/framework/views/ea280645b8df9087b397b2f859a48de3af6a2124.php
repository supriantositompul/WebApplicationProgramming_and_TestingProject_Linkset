<?php echo e($slot); ?>

<?php /**PATH D:\MATERI KULIAH\Semester 5\LinkSet-Project-PPAW-Api-Progress\LinkSet-Project-PPAW\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>