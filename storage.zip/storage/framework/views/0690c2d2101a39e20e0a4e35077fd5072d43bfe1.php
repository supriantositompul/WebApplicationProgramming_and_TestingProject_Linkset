<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\MATERI KULIAH\Semester 5\LinkSet-Project-PPAW-Api-Progress\LinkSet-Project-PPAW\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>