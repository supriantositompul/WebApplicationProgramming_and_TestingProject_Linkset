<?php $__env->startSection('style'); ?>
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        .livesearch {
            margin: 100px;
            background-color: #636b6f
        }

        ..newStyle {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, 50%);
            background: #2f3640;
            height: 40px;
            border-radius: 40px;
            padding: 10px;

        }

        @import  url('https://fonts.googleapis.com/css?family=Raleway:400,700');

        *,
        *:before,
        *:after {
            box-sizing: border-box
        }

        body {
            min-height: 100vh;
            font-family: 'Raleway', sans-serif;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <body>


        <div class="container">
            <div class="row justify-content-center">
                <div class="content">
                    <div class="title" style="color: #fff">
                        Linkset
                    </div>
                    <select name="livesearch" class="form-control livesearch newStyle" id=""></select>
                </div>
            </div>
        </div>
    </body>

    <script>
        let $q = $('.livesearch');

        $q.select2({
            placeholder: "Search Username",
            ajax: {
                url: "/search",
                dataType: 'json',
                delay: 250,
                processResults: function(data) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                id: item.id,
                                text: item.username,
                                username_slug: item.username_slug,
                            }
                        })
                    };
                },
                cache: true
            }
        });

        $q.on('select2:select', function(e) {
            window.location.href = "/" + e.params.data.username_slug;
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MATERI KULIAH\Semester 5\LinkSet-Project-PPAW-Api-Progress\LinkSet-Project-PPAW\resources\views/home.blade.php ENDPATH**/ ?>